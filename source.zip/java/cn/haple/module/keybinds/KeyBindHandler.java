package cn.haple.module.keybinds;

import java.util.List;
import me.zane.basicbus.api.annotations.Listener;
import cn.haple.events.game.KeyPressEvent;
import cn.haple.module.Module;
import cn.haple.module.ModuleManager;

public final class KeyBindHandler {
   private final ModuleManager moduleManager;

   public KeyBindHandler(ModuleManager moduleManager) {
      this.moduleManager = moduleManager;
   }

   @Listener(KeyPressEvent.class)
   public final void onKeyPress(KeyPressEvent event) {
      List modules = this.moduleManager.getModules();
      int i = 0;

      for(int keysSize = modules.size(); i < keysSize; ++i) {
         Module module = (Module)modules.get(i);
         if (event.getKeyCode() == module.getKeyBind().getKeyCode()) {
            module.toggle();
         }
      }

   }
}
