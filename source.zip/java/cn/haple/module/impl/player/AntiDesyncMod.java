package cn.haple.module.impl.player;

import me.zane.basicbus.api.annotations.Listener;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import cn.haple.annotations.Label;
import cn.haple.events.packet.ReceivePacketEvent;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Aliases;
import cn.haple.module.annotations.Category;

@Label("Anti Desync")
@Category(ModuleCategory.PLAYER)
@Aliases({"antidesync", "norotations"})
public final class AntiDesyncMod extends Module {
   @Listener(ReceivePacketEvent.class)
   public void onEvent(ReceivePacketEvent event) {
      if (event.getPacket() instanceof S08PacketPlayerPosLook) {
         S08PacketPlayerPosLook packet = (S08PacketPlayerPosLook)event.getPacket();
         packet.setYaw(mc.thePlayer.rotationYaw);
         packet.setPitch(mc.thePlayer.rotationPitch);
      }

   }
}
