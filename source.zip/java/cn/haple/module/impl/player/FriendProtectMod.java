package cn.haple.module.impl.player;

import cn.haple.annotations.Label;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Aliases;
import cn.haple.module.annotations.Category;

@Label("Friend Protect")
@Category(ModuleCategory.PLAYER)
@Aliases({"friendprotect", "friendprot", "friends"})
public final class FriendProtectMod extends Module {
}
