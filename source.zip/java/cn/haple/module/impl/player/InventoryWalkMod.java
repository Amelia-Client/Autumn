package cn.haple.module.impl.player;

import cn.haple.annotations.Label;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Aliases;
import cn.haple.module.annotations.Category;

@Label("Inventory Walk")
@Category(ModuleCategory.PLAYER)
@Aliases({"inventorywalk", "invwalk", "invmove"})
public final class InventoryWalkMod extends Module {
}
