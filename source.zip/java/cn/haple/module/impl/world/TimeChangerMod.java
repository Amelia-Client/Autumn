package cn.haple.module.impl.world;

import cn.haple.annotations.Label;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Aliases;
import cn.haple.module.annotations.Category;
import cn.haple.module.option.Option;
import cn.haple.module.option.impl.DoubleOption;

@Label("Time Changer")
@Category(ModuleCategory.WORLD)
@Aliases({"timechanger", "worldtime"})
public final class TimeChangerMod extends Module {
   public final DoubleOption time = new DoubleOption("Time", 16000.0D, 1.0D, 24000.0D, 100.0D);

   public TimeChangerMod() {
      this.addOptions(new Option[]{this.time});
   }
}
