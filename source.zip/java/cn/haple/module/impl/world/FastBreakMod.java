package cn.haple.module.impl.world;

import me.zane.basicbus.api.annotations.Listener;
import net.minecraft.block.Block;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.util.BlockPos;
import cn.haple.annotations.Label;
import cn.haple.events.player.BlockDamagedEvent;
import cn.haple.events.player.MotionUpdateEvent;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Aliases;
import cn.haple.module.annotations.Category;

@Label("Fast Break")
@Category(ModuleCategory.WORLD)
@Aliases({"fastbreak"})
public final class FastBreakMod extends Module {
   @Listener(MotionUpdateEvent.class)
   public final void onUpdate(MotionUpdateEvent event) {
      if (event.isPre()) {
         mc.playerController.blockHitDelay = 0;
      }

   }

   @Listener(BlockDamagedEvent.class)
   public void onBlockDamaged(BlockDamagedEvent event) {
      PlayerControllerMP playerController = mc.playerController;
      BlockPos pos = event.getBlockPos();
      mc.thePlayer.swingItem();
      playerController.curBlockDamageMP += this.getBlock((double)pos.getX(), (double)pos.getY(), (double)pos.getZ()).getPlayerRelativeBlockHardness(mc.thePlayer, mc.theWorld, pos) * 0.186F;
   }

   public Block getBlock(double posX, double posY, double posZ) {
      BlockPos pos = new BlockPos((int)posX, (int)posY, (int)posZ);
      return mc.theWorld.getChunkFromBlockCoords(pos).getBlock(pos);
   }
}
