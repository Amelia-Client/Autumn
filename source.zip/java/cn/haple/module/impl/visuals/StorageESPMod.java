package cn.haple.module.impl.visuals;

import java.awt.Color;
import cn.haple.annotations.Label;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Aliases;
import cn.haple.module.annotations.Category;
import cn.haple.module.option.impl.EnumOption;

@Label("Storage ESP")
@Category(ModuleCategory.VISUALS)
@Aliases({"storageesp", "chestesp"})
public final class StorageESPMod extends Module {
   private final int chestColor = (new Color(250, 138, 19)).getRGB();
   public final EnumOption mode;

   public StorageESPMod() {
      this.mode = new EnumOption("Mode", StorageESPMod.Mode.BOX);
   }

   public static enum Mode {
      BOX;
   }
}
