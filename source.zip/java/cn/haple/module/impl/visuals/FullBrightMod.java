package cn.haple.module.impl.visuals;

import me.zane.basicbus.api.annotations.Listener;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import cn.haple.annotations.Label;
import cn.haple.events.game.TickEvent;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Aliases;
import cn.haple.module.annotations.Category;

@Label("Full Bright")
@Category(ModuleCategory.VISUALS)
@Aliases({"fullbright", "brightness"})
public final class FullBrightMod extends Module {
   @Listener(TickEvent.class)
   public final void onTick() {
      mc.thePlayer.addPotionEffect(new PotionEffect(Potion.nightVision.getId(), 1000000, 2));
   }

   public void onDisabled() {
      mc.thePlayer.removePotionEffect(Potion.nightVision.getId());
   }
}
