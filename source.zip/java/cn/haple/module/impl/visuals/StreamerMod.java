package cn.haple.module.impl.visuals;

import me.zane.basicbus.api.annotations.Listener;
import cn.haple.annotations.Label;
import cn.haple.events.render.RenderNametagEvent;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Category;
import cn.haple.module.option.Option;
import cn.haple.module.option.impl.BoolOption;

@Label("Streamer")
@Category(ModuleCategory.VISUALS)
public final class StreamerMod extends Module {
   public static final String ENEMY = "Enemy";
   public static final String YOU = "You";
   public static final String FRIEND = "Friend";
   public final BoolOption hideScoreboard = new BoolOption("Hide Scoreboard", true);
   public final BoolOption hideChat = new BoolOption("Hide Chat", true);

   public StreamerMod() {
      this.addOptions(new Option[]{this.hideScoreboard, this.hideChat});
   }

   public boolean shouldHideScoreboard() {
      return this.isEnabled() && this.hideScoreboard.getValue();
   }

   public boolean shouldHideChat() {
      return this.isEnabled() && this.hideChat.getValue();
   }

   @Listener(RenderNametagEvent.class)
   public void onRenderNameTag(RenderNametagEvent event) {
      event.setRenderedName("Enemy");
   }
}
