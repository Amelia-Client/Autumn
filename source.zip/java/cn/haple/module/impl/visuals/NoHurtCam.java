package cn.haple.module.impl.visuals;

import cn.haple.annotations.Label;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Aliases;
import cn.haple.module.annotations.Category;

@Label("No Hurt Cam")
@Category(ModuleCategory.VISUALS)
@Aliases({"nohurtcam", "nohurt", "camera"})
public final class NoHurtCam extends Module {
}
