package cn.haple.module.impl.visuals;

import cn.haple.annotations.Label;
import cn.haple.clickgui.ClickGuiScreen;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Aliases;
import cn.haple.module.annotations.Bind;
import cn.haple.module.annotations.Category;

@Label("Click GUI")
@Bind("RSHIFT")
@Category(ModuleCategory.VISUALS)
@Aliases({"clickgui", "gui"})
public final class ClickGUIMod extends Module {
   public ClickGUIMod() {
      this.setHidden(true);
   }

   public void onEnabled() {
      mc.displayGuiScreen(ClickGuiScreen.getInstance());
      this.setEnabled(false);
   }
}
