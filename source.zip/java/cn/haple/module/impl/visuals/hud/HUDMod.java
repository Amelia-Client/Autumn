package cn.haple.module.impl.visuals.hud;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import me.zane.basicbus.api.annotations.Listener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import cn.haple.annotations.Label;
import cn.haple.core.Haple;
import cn.haple.events.render.RenderGuiEvent;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Category;
import cn.haple.module.impl.visuals.hud.impl.InfoComponent;
import cn.haple.module.impl.visuals.hud.impl.ModList;
import cn.haple.module.impl.visuals.hud.impl.Watermark;
import cn.haple.module.option.Option;
import cn.haple.module.option.impl.BoolOption;
import cn.haple.module.option.impl.ColorOption;
import cn.haple.module.option.impl.DoubleOption;
import cn.haple.module.option.impl.EnumOption;

@Label("HUD")
@Category(ModuleCategory.VISUALS)
public final class HUDMod extends Module {
   public static String clientName;
   private static final Minecraft mc;
   public final ColorOption color = new ColorOption("Color", new Color(145, 52, 203));
   public final EnumOption arrayListPosition;
   public final BoolOption watermark;
   public final BoolOption defaultFont;
   public final EnumOption infoDisplayMode;
   public final EnumOption modListColorMode;
   public final BoolOption modListSideBar;
   public final BoolOption modListOutline;
   public final BoolOption modListBackground;
   public final DoubleOption modListBackgroundAlpha;
   private final List components;

   public HUDMod() {
      this.arrayListPosition = new EnumOption("ModListPosition", HUDMod.ArrayListPosition.TOP);
      this.watermark = new BoolOption("Watermark", true);
      this.defaultFont = new BoolOption("DefaultFont", false);
      this.infoDisplayMode = new EnumOption("InfoDisplayMode", HUDMod.InfoDisplayMode.LEFT);
      this.modListColorMode = new EnumOption("ModListColorMode", HUDMod.ArrayListColor.PULSING);
      this.modListSideBar = new BoolOption("ModListSideBar", false);
      this.modListOutline = new BoolOption("ModListOutline", true);
      this.modListBackground = new BoolOption("ModListBackground", true);
      this.modListBackgroundAlpha = new DoubleOption("ModListBackgroundAlpha", 0.2D, 0.0D, 1.0D, 0.05D);
      this.components = new ArrayList();
      this.setEnabled(true);
      this.setHidden(true);
      this.components.add(new ModList(this));
      this.components.add(new Watermark(this));
      this.components.add(new InfoComponent(this));
      this.addOptions(new Option[]{this.color, this.defaultFont, this.infoDisplayMode, this.arrayListPosition, this.modListColorMode, this.modListSideBar, this.modListOutline, this.modListBackground, this.modListBackgroundAlpha, this.watermark});
   }

   @Listener(RenderGuiEvent.class)
   public final void onRenderGui(RenderGuiEvent event) {
      if (!mc.gameSettings.showDebugInfo) {
         ScaledResolution sr = event.getScaledResolution();
         int i = 0;

         for(int componentsSize = this.components.size(); i < componentsSize; ++i) {
            Component component = (Component)this.components.get(i);
            component.draw(sr);
         }

      }
   }

   static {
      clientName = Haple.INSTANCE.getName() + " " + Haple.INSTANCE.getVersion();
      mc = Minecraft.getMinecraft();
   }

   public static enum InfoDisplayMode {
      LEFT,
      RIGHT,
      OFF;
   }

   public static enum ArrayListColor {
      STATIC,
      PULSING,
      RAINBOW;
   }

   public static enum ArrayListPosition {
      BOTTOM,
      TOP;
   }
}
