package cn.haple.module.impl.visuals;

import cn.haple.annotations.Label;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Category;
import cn.haple.module.option.Option;
import cn.haple.module.option.impl.EnumOption;
import cn.haple.utils.render.Palette;

@Label("Chams")
@Category(ModuleCategory.VISUALS)
public final class ChamsMod extends Module {
   public final EnumOption mode;
   public final EnumOption player;
   public final EnumOption playerBehindWalls;
   public static final int HANDCOL = -1253464587;

   public ChamsMod() {
      this.mode = new EnumOption("Mode", ChamsMod.Mode.COLOR);
      this.player = new EnumOption("Player", Palette.PURPLE);
      this.playerBehindWalls = new EnumOption("Player behind walls", Palette.PURPLE);
      this.addOptions(new Option[]{this.mode, this.player, this.playerBehindWalls});
   }

   public static enum Mode {
      COLOR,
      TEXTURED;
   }
}
