package cn.haple.module.impl.visuals;

import java.awt.Color;
import cn.haple.annotations.Label;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Aliases;
import cn.haple.module.annotations.Category;
import cn.haple.module.option.Option;
import cn.haple.module.option.impl.ColorOption;

@Label("Damage Color")
@Category(ModuleCategory.VISUALS)
@Aliases({"damagecolor"})
public final class DamageColorMod extends Module {
   public static final ColorOption color = new ColorOption("Color", new Color(255, 0, 0, 76));

   public DamageColorMod() {
      this.addOptions(new Option[]{color});
   }
}
