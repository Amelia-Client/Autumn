package cn.haple.module.impl.movement;

import me.zane.basicbus.api.annotations.Listener;
import net.minecraft.client.entity.EntityPlayerSP;
import cn.haple.annotations.Label;
import cn.haple.events.player.MoveEvent;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Category;

@Label("Sprint")
@Category(ModuleCategory.MOVEMENT)
public final class SprintMod extends Module {
   @Listener(MoveEvent.class)
   public void onMove() {
      EntityPlayerSP player = mc.thePlayer;
      if (player.isMoving() && player.getFoodStats().getFoodLevel() > 6) {
         player.setSprinting(true);
      }

   }
}
