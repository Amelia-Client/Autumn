package cn.haple.module.impl.movement;

import me.zane.basicbus.api.annotations.Listener;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.network.play.client.C03PacketPlayer;
import cn.haple.annotations.Label;
import cn.haple.events.player.MotionUpdateEvent;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Aliases;
import cn.haple.module.annotations.Category;
import cn.haple.module.option.Option;
import cn.haple.module.option.impl.DoubleOption;
import cn.haple.utils.PlayerUtils;
import cn.haple.utils.Stopwatch;

@Label("Anti Fall")
@Category(ModuleCategory.MOVEMENT)
@Aliases({"antifall", "antivoid", "novoid"})
public final class AntiFallMod extends Module {
   private final Stopwatch fallStopwatch = new Stopwatch();
   public final DoubleOption distance = new DoubleOption("Distance", 5.0D, 3.0D, 10.0D, 0.5D);

   public AntiFallMod() {
      this.addOptions(new Option[]{this.distance});
   }

   @Listener(MotionUpdateEvent.class)
   public void onMotionUpdate(MotionUpdateEvent event) {
      EntityPlayerSP player = mc.thePlayer;
      if ((double)player.fallDistance > (Double)this.distance.getValue() && !player.capabilities.isFlying && this.fallStopwatch.elapsed(250L) && !PlayerUtils.isBlockUnder()) {
         mc.getNetHandler().addToSendQueueSilent(new C03PacketPlayer.C04PacketPlayerPosition(player.posX, player.posY + (Double)this.distance.getValue() + 1.0D, player.posZ, false));
         this.fallStopwatch.reset();
      }
   }
}
