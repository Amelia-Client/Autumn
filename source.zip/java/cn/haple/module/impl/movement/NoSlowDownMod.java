package cn.haple.module.impl.movement;

import me.zane.basicbus.api.annotations.Listener;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import cn.haple.annotations.Label;
import cn.haple.events.player.MotionUpdateEvent;
import cn.haple.events.player.UseItemEvent;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Aliases;
import cn.haple.module.annotations.Category;
import cn.haple.module.impl.combat.KillAuraMod;
import cn.haple.module.option.Option;
import cn.haple.module.option.impl.BoolOption;
import cn.haple.utils.PlayerUtils;

@Label("NoSlowDown")
@Category(ModuleCategory.MOVEMENT)
@Aliases({"noslow", "noslowdown"})
public final class NoSlowDownMod extends Module {
   public final BoolOption ncp = new BoolOption("NCP", true);

   public NoSlowDownMod() {
      this.addOptions(new Option[]{this.ncp});
   }

   @Listener(UseItemEvent.class)
   public final void onUseItem(UseItemEvent event) {
      event.setCancelled();
   }

   @Listener(MotionUpdateEvent.class)
   public final void onMotionUpdate(MotionUpdateEvent event) {
      if (this.ncp.getValue() && this.isBlocking() && mc.thePlayer.isMoving() && mc.thePlayer.onGround) {
         if (event.isPre()) {
            mc.playerController.syncCurrentPlayItem();
            mc.getNetHandler().addToSendQueueSilent(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
         } else {
            mc.playerController.syncCurrentPlayItem();
            mc.getNetHandler().addToSendQueueSilent(new C08PacketPlayerBlockPlacement(mc.thePlayer.getCurrentEquippedItem()));
         }
      }

   }

   private boolean isBlocking() {
      return PlayerUtils.isHoldingSword() && mc.thePlayer.isBlocking() && !KillAuraMod.blocking;
   }
}
