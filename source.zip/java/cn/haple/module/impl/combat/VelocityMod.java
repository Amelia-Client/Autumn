package cn.haple.module.impl.combat;

import me.zane.basicbus.api.annotations.Listener;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.network.play.server.S27PacketExplosion;
import cn.haple.annotations.Label;
import cn.haple.events.packet.ReceivePacketEvent;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Category;

@Label("Velocity")
@Category(ModuleCategory.COMBAT)
public final class VelocityMod extends Module {
   @Listener(ReceivePacketEvent.class)
   public void onReceivePacket(ReceivePacketEvent event) {
      Packet packet = event.getPacket();
      if (packet instanceof S12PacketEntityVelocity || packet instanceof S27PacketExplosion) {
         event.setCancelled();
      }
   }
}
