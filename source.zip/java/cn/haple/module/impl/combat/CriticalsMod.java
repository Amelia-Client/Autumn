package cn.haple.module.impl.combat;

import cn.haple.annotations.Label;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Category;

@Label("Criticals")
@Category(ModuleCategory.COMBAT)
public final class CriticalsMod extends Module {
}
