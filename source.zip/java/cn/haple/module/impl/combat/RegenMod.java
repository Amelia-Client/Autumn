package cn.haple.module.impl.combat;

import me.zane.basicbus.api.annotations.Listener;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.potion.Potion;
import cn.haple.annotations.Label;
import cn.haple.events.game.TickEvent;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Category;
import cn.haple.module.option.Option;
import cn.haple.module.option.impl.DoubleOption;
import cn.haple.module.option.impl.EnumOption;

@Label("Regen")
@Category(ModuleCategory.COMBAT)
public final class RegenMod extends Module {
   public static final EnumOption mode;
   public static final DoubleOption packets;

   public RegenMod() {
      this.setMode(mode);
      this.addOptions(new Option[]{mode, packets});
   }

   @Listener(TickEvent.class)
   public void onTick() {
      switch(mode.getValue().toString()) {
      case "PACKET":
         this.packetRegen(((Double)packets.getValue()).intValue());
         break;
      case "POTION":
         if (mc.thePlayer.isPotionActive(Potion.regeneration)) {
            this.packetRegen((int)((Double)packets.getValue() / 2.0D * (double)mc.thePlayer.getActivePotionEffect(Potion.regeneration).getAmplifier()));
         }
      }

   }

   private void packetRegen(int packets) {
      if (mc.thePlayer.onGround) {
         for(int i = 0; i < packets; ++i) {
            mc.getNetHandler().addToSendQueueSilent(new C03PacketPlayer(true));
         }
      }

   }

   static {
      mode = new EnumOption("Mode", RegenMod.Mode.POTION);
      packets = new DoubleOption("Packets", 10.0D, 1.0D, 1000.0D, 1.0D);
   }

   private enum Mode {
      PACKET,
      POTION;
   }
}
