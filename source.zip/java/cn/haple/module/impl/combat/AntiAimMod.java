package cn.haple.module.impl.combat;

import me.zane.basicbus.api.annotations.Listener;
import cn.haple.annotations.Label;
import cn.haple.events.player.MotionUpdateEvent;
import cn.haple.module.Module;
import cn.haple.module.ModuleCategory;
import cn.haple.module.annotations.Aliases;
import cn.haple.module.annotations.Category;
import cn.haple.module.option.Option;
import cn.haple.module.option.impl.EnumOption;

@Label("Anti Aim")
@Category(ModuleCategory.COMBAT)
@Aliases({"antiaim", "aa"})
public final class AntiAimMod extends Module {
   public final EnumOption yawMode;
   public final EnumOption pitchMode;
   private float yaw;
   private float pitch;

   public AntiAimMod() {
      this.yawMode = new EnumOption("Yaw mode", AntiAimMod.YawMode.JITTER);
      this.pitchMode = new EnumOption("Pitch mode", AntiAimMod.PitchMode.DOWN);
      this.addOptions(new Option[]{this.pitchMode, this.yawMode});
   }

   @Listener(MotionUpdateEvent.class)
   public void onMotionUpdate(MotionUpdateEvent event) {
      if (!mc.thePlayer.isSwingInProgress) {
         switch(yawMode.getValue().toString()) {
         case "SPIN":
            this.yaw += 20.0F;
            if (this.yaw > 180.0F) {
               this.yaw = -180.0F;
            } else if (this.yaw < -180.0F) {
               this.yaw = 180.0F;
            }
            break;
         case "JITTER":
            this.yaw = (float)(mc.thePlayer.ticksExisted % 2 == 0 ? 90 : -90);
         }

         event.setYaw(this.yaw);
         switch(pitchMode.getValue().toString()) {
         case "UP":
            this.pitch = -90.0F;
            break;
         case "DOWN":
            this.pitch = 90.0F;
            break;
         case "JITTER":
            this.pitch += 30.0F;
            if (this.pitch > 90.0F) {
               this.pitch = -90.0F;
            } else if (this.pitch < -90.0F) {
               this.pitch = 90.0F;
            }
         }

         event.setPitch(this.pitch);
      }

   }

   private enum PitchMode {
      DOWN,
      UP,
      JITTER;
   }

   private enum YawMode {
      JITTER,
      SPIN;
   }
}
