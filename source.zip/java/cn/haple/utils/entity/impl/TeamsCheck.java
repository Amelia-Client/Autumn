package cn.haple.utils.entity.impl;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import cn.haple.module.option.impl.BoolOption;
import cn.haple.utils.PlayerUtils;
import cn.haple.utils.entity.ICheck;

public final class TeamsCheck implements ICheck {
   private final BoolOption teams;

   public TeamsCheck(BoolOption teams) {
      this.teams = teams;
   }

   public boolean validate(Entity entity) {
      return !(entity instanceof EntityPlayer) || !PlayerUtils.isOnSameTeam((EntityPlayer)entity) || !this.teams.getValue();
   }
}
