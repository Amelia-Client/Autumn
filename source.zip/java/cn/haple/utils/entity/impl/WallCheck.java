package cn.haple.utils.entity.impl;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import cn.haple.utils.entity.ICheck;

public final class WallCheck implements ICheck {
   public boolean validate(Entity entity) {
      return Minecraft.getMinecraft().thePlayer.canEntityBeSeen(entity);
   }
}
