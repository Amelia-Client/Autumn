package cn.haple.events.render;

import net.minecraft.client.gui.ScaledResolution;
import cn.haple.events.Cancellable;
import cn.haple.events.Event;

public final class RenderCrosshairEvent extends Cancellable implements Event {
   private final ScaledResolution sr;

   public RenderCrosshairEvent(ScaledResolution sr) {
      this.sr = sr;
   }

   public ScaledResolution getScaledRes() {
      return this.sr;
   }
}
