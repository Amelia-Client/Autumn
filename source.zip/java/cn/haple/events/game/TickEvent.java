package cn.haple.events.game;

import cn.haple.events.Event;

public final class TickEvent implements Event {
}
