package cn.haple.events.player;

import cn.haple.events.Event;

public final class DieEvent implements Event {
}
