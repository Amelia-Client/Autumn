package cn.haple.events.player;

import net.minecraft.entity.Entity;
import cn.haple.events.Cancellable;
import cn.haple.events.Event;

public final class AttackEvent extends Cancellable implements Event {
   private final Entity entity;

   public AttackEvent(Entity entity) {
      this.entity = entity;
   }

   public Entity getEntity() {
      return this.entity;
   }
}
