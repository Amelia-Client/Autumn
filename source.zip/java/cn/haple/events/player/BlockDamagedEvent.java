package cn.haple.events.player;

import net.minecraft.util.BlockPos;
import cn.haple.events.Cancellable;
import cn.haple.events.Event;

public final class BlockDamagedEvent extends Cancellable implements Event {
   private final BlockPos blockPos;

   public BlockDamagedEvent(BlockPos blockPos) {
      this.blockPos = blockPos;
   }

   public BlockPos getBlockPos() {
      return this.blockPos;
   }
}
