package cn.haple.events.player;

import cn.haple.events.Cancellable;
import cn.haple.events.Event;

public final class PushEvent extends Cancellable implements Event {
}
