package cn.haple.events.packet;

import net.minecraft.network.Packet;
import cn.haple.events.Cancellable;
import cn.haple.events.Event;

public final class SendPacketEvent extends Cancellable implements Event {
   private final Packet packet;

   public SendPacketEvent(Packet packet) {
      this.packet = packet;
   }

   public Packet getPacket() {
      return this.packet;
   }
}
