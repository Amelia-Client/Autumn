package cn.haple.events;

public interface Event {
}
