package cn.haple.menu;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.util.ResourceLocation;
import cn.haple.alt.gui.GuiAltManager;
import cn.haple.menu.buttons.SimpleButton;
import cn.haple.utils.render.RenderUtils;

public final class AutumnMainMenu extends GuiScreen {
   private ResourceLocation background = new ResourceLocation("autumn/menu/background.png");

   public void initGui() {
      super.initGui();
      this.buttonList.add(new SimpleButton(0, this.width / 2, this.height / 2 - 40, "Single"));
      this.buttonList.add(new SimpleButton(1, this.width / 2, this.height / 2 - 20, "Multi"));
      this.buttonList.add(new SimpleButton(2, this.width / 2, this.height / 2, "AltManager"));
      this.buttonList.add(new SimpleButton(3, this.width / 2, this.height / 2 + 20, "Settings"));
      this.buttonList.add(new SimpleButton(4, this.width / 2, this.height / 2 + 40, "Exit"));
   }

   protected void actionPerformed(GuiButton button) {
      switch(button.id) {
      case 0:
         this.mc.displayGuiScreen(new GuiSelectWorld(this));
         break;
      case 1:
         this.mc.displayGuiScreen(new GuiMultiplayer(this));
         break;
      case 2:
         this.mc.displayGuiScreen(new GuiAltManager(this));
         break;
      case 3:
         this.mc.displayGuiScreen(new GuiOptions(this, this.mc.gameSettings));
         break;
      case 4:
         System.exit(0);
      }

   }

   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      RenderUtils.drawImg(this.background, 0.0D, 0.0D, (double)this.width, (double)this.height);
      super.drawScreen(mouseX, mouseY, partialTicks);
   }
}
