package cn.haple.command;

@FunctionalInterface
public interface Command {
   void execute(String... var1);
}
