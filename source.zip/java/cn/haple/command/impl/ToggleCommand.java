package cn.haple.command.impl;

import cn.haple.command.AbstractCommand;
import cn.haple.core.Haple;
import cn.haple.module.Module;
import cn.haple.utils.Logger;

public final class ToggleCommand extends AbstractCommand {
   public ToggleCommand() {
      super("Toggle", "Toggle modules on and off.", "toggle <module>", "toggle", "t");
   }

   public void execute(String... arguments) {
      if (arguments.length == 2) {
         String moduleName = arguments[1];
         Module module = Haple.MANAGER_REGISTRY.moduleManager.getModuleOrNull(moduleName);
         if (module != null) {
            module.toggle();
         } else {
            Logger.log("'" + moduleName + "' is not a module.");
         }
      } else {
         this.usage();
      }

   }
}
