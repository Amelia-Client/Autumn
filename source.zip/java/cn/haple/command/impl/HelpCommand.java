package cn.haple.command.impl;

import java.util.Iterator;
import cn.haple.command.AbstractCommand;
import cn.haple.core.Haple;
import cn.haple.utils.Logger;

public final class HelpCommand extends AbstractCommand {
   public HelpCommand() {
      super("Help", "Lists all commands.", "help", "help", "h");
   }

   public void execute(String... arguments) {
      if (arguments.length == 1) {
         Logger.log("---------------- Help ----------------");
         Iterator var2 = Haple.MANAGER_REGISTRY.commandManager.getCommands().iterator();

         while(var2.hasNext()) {
            AbstractCommand command = (AbstractCommand)var2.next();
            Logger.log(command.getName() + ": §F" + command.getDescription());
         }
      } else {
         this.usage();
      }

   }
}
