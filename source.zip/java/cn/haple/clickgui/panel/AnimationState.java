package cn.haple.clickgui.panel;

public enum AnimationState {
   RETRACTING,
   EXPANDING,
   STATIC;
}
