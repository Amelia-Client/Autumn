package cn.haple.core.registry.impl;

import cn.haple.command.CommandManager;
import cn.haple.config.ConfigManager;
import cn.haple.core.registry.Registry;
import cn.haple.file.FileManager;
import cn.haple.friend.FriendManager;
import cn.haple.module.ModuleManager;

public final class ManagerRegistry implements Registry {
   public final ConfigManager configManager = new ConfigManager();
   public final FileManager fileManager = new FileManager();
   public final FriendManager friendManager = new FriendManager();
   public final ModuleManager moduleManager = new ModuleManager();
   public final CommandManager commandManager = new CommandManager();
}
