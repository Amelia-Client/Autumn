package cn.haple.core.registry.impl;

import me.zane.basicbus.api.bus.Bus;
import me.zane.basicbus.api.bus.impl.EventBusImpl;
import me.zane.basicbus.api.invocation.impl.ReflectionInvoker;
import cn.haple.core.registry.Registry;

public final class EventBusRegistry implements Registry {
   public final Bus eventBus = new EventBusImpl(new ReflectionInvoker());
}
