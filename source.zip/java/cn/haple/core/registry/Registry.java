package cn.haple.core.registry;

public interface Registry {
}
