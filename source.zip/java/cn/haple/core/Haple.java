package cn.haple.core;

import org.lwjgl.opengl.Display;
import cn.haple.core.registry.impl.EventBusRegistry;
import cn.haple.core.registry.impl.ManagerRegistry;

public final class Haple {
   public static final Haple INSTANCE = builder().name("Haple Fix").version("1.0.0").authors("Zane", "Imminent", "NullEX").build();
   public static final EventBusRegistry EVENT_BUS_REGISTRY = new EventBusRegistry();
   public static final ManagerRegistry MANAGER_REGISTRY = new ManagerRegistry();
   private final String name;
   private final String version;
   private final String[] authors;

   private Haple(String name, String version, String[] authors) {
      this.name = name;
      this.version = version;
      this.authors = authors;
   }

   private static Haple.Builder builder() {
      return new Haple.Builder();
   }

   public String getName() {
      return this.name;
   }

   public String getVersion() {
      return this.version;
   }

   public String[] getAuthors() {
      return this.authors;
   }

   public void start() {
      Runtime.getRuntime().addShutdownHook(new Thread(this::stop));
      Display.setTitle(this.name + " " + this.version);
   }

   public void stop() {
      MANAGER_REGISTRY.moduleManager.saveData();
   }

   public static class Builder {
      private String name;
      private String version;
      private String[] authors;

      protected Builder() {
      }

      public Haple.Builder name(String name) {
         this.name = name;
         return this;
      }

      public Haple.Builder version(String version) {
         this.version = version;
         return this;
      }

      public Haple.Builder authors(String... authors) {
         this.authors = authors;
         return this;
      }

      public final Haple build() {
         return new Haple(this.name, this.version, this.authors);
      }
   }
}
