package javax.vecmath;

public class MismatchedSizeException extends RuntimeException {
   public MismatchedSizeException() {
   }

   public MismatchedSizeException(String var1) {
      super(var1);
   }
}
